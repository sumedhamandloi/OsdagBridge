"""Pier checks stub."""
