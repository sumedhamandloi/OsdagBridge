"""Pier cap geometry stub."""
