"""Pile cap geometry stub."""
