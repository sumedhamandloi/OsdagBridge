"""Pile geometry stub."""
