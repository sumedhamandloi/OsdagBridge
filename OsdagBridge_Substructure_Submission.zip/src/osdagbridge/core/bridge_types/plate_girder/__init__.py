"""plate_girder module."""
