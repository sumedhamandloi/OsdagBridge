"""box_girder module."""
