"""truss designer (stub)."""
