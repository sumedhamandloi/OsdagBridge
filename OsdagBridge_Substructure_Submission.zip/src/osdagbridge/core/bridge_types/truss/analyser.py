"""truss analyser (stub)."""
