"""
Converts raw LaTeX math expressions into clean Unicode typography
suitable for Google Docs markdown import.
"""
import re

with open("tools/build_comprehensive_report.py", "r", encoding="utf-8") as f:
    content = f.read()

# Replace common math symbols
content = content.replace(r"\\rightarrow", "→")
content = content.replace(r"\rightarrow", "→")
content = content.replace(r"\varnothing", "Ø")
content = content.replace(r"\\varnothing", "Ø")
content = content.replace(r"\\times", "×")
content = content.replace(r"\times", "×")
content = content.replace(r"\\pm", "±")
content = content.replace(r"\pm", "±")

# Clean display math blocks $$...$$
def clean_block(match):
    inner = match.group(1).strip()
    inner = inner.replace(r"\text{", "").replace("}", "")
    inner = inner.replace(r"\left(", "(").replace(r"\right)", ")")
    inner = re.sub(r"\\+frac\{([^}]+)\}\{([^}]+)\}", r"(\1 / \2)", inner)
    inner = inner.replace(r"\_", "_")
    inner = inner.replace(r"\quad", "   ")
    inner = inner.replace(r"\Delta", "Δ")
    return "> **" + inner + "**"

content = re.sub(r"\$\$([^\$]+)\$\$", clean_block, content)

# Clean inline math $...$
def clean_inline(match):
    inner = match.group(1).strip()
    inner = inner.replace(r"\text{", "").replace("}", "")
    inner = inner.replace(r"\_", "_")
    inner = inner.replace(r"\Delta", "Δ")
    inner = inner.replace(r"\cdot", "·")
    inner = re.sub(r"\\+frac\{([^}]+)\}\{([^}]+)\}", r"(\1 / \2)", inner)
    return inner

content = re.sub(r"\$([^\$\n]+)\$", clean_inline, content)

with open("tools/build_comprehensive_report.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Updated build_comprehensive_report.py successfully")
