"""
End-to-End Verification Test for Bridge Substructure IFC4 Export
"""

import sys
import os
from pathlib import Path

# Add src to path
SRC_DIR = Path(__file__).resolve().parents[1] / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import ifcopenshell
from osdagbridge.core.bridge_types.plate_girder.dto import (
    BridgeParametersDTO,
    SectionDimsDTO,
    ISectionDimsDTO,
    ShearStudParamsDTO,
    GirderSegmentDTO
)
from osdagbridge.core.bridge_types.plate_girder.cad_generator import PlateGirderCADGenerator
from osdagbridge.core.ifc_export_bridge.bridge_cad_extraction import PlateGirderIFCExtractor
from osdagbridge.core.ifc_export_bridge.bridge_ifc_generator import BridgeIfcGenerator

def get_sample_bridge_params():
    return BridgeParametersDTO(
        steel_grade="E 250 (Fe 410 W) A",
        concrete_grade="M 35",
        span_length_L=25000.0,
        girder_section_d=900.0,
        girder_section_bf=500.0,
        girder_section_bf_b=500.0,
        girder_section_tf=26.0,
        girder_section_tf_b=26.0,
        girder_section_tw=10.0,
        num_girders=3,
        girder_spacing=2500.0,
        skew_angle=0.0,
        carriageway_width=7500.0,
        deck_thickness=250.0,
        footpath_config="NONE",
        footpath_width=1500.0,
        railing_width=300.0,
        barrier_type="Rigid",
        crash_barrier_subtype="IRC-5R",
        enable_median=False,
        median_type="RCC Crash Barrier",
        rail_count=3,
        railing_type="rcc",
        include_intermediate_stiffeners=True,
        intermediate_stiffener_spacing=2000.0,
        intermediate_stiffener_thickness=12.0,
        intermediate_stiffener_outstand=None,
        num_end_stiffener_pairs=2,
        end_stiffener_thickness=16.0,
        end_stiffener_outstand=None,
        include_longitudinal_stiffeners=False,
        num_longitudinal_stiffeners=1,
        longitudinal_stiffener_thickness=12.0,
        longitudinal_stiffener_outstand=None,
        cross_bracing_spacing=4000.0,
        bracing_type="X",
        x_bracket_option="NONE",
        k_top_bracket=False,
        diagonal_section_type="ANGLE",
        diagonal_section_dims=SectionDimsDTO(leg_h=100.0, leg_w=50.0, connection_type="LONGER_LEG"),
        diagonal_thickness=6.0,
        top_chord_section_type="ANGLE",
        top_chord_section_dims=SectionDimsDTO(leg_h=80.0, leg_w=40.0, connection_type="LONGER_LEG"),
        top_chord_thickness=6.0,
        bottom_chord_section_type="ANGLE",
        bottom_chord_section_dims=SectionDimsDTO(leg_h=80.0, leg_w=40.0, connection_type="LONGER_LEG"),
        bottom_chord_thickness=6.0,
        end_diaphragm_type="Cross Bracing",
        end_diaphragm_spacing=100.0,
        end_diaphragm_bracing_type="X",
        end_diaphragm_diagonal_section_type="ANGLE",
        end_diaphragm_diagonal_section_dims=SectionDimsDTO(leg_h=100.0, leg_w=50.0, connection_type="LONGER_LEG"),
        end_diaphragm_diagonal_thickness=6.0,
        end_diaphragm_top_chord_section_type="ANGLE",
        end_diaphragm_top_chord_section_dims=SectionDimsDTO(leg_h=80.0, leg_w=40.0, connection_type="LONGER_LEG"),
        end_diaphragm_top_chord_thickness=6.0,
        end_diaphragm_bottom_chord_section_type="ANGLE",
        end_diaphragm_bottom_chord_section_dims=SectionDimsDTO(leg_h=80.0, leg_w=40.0, connection_type="LONGER_LEG"),
        end_diaphragm_bottom_chord_thickness=6.0,
        end_diaphragm_section="I_SECTION",
        end_diaphragm_dims=ISectionDimsDTO(depth=800.0, flange_width=250.0, web_thickness=12.0, flange_thickness=16.0),
        shear_stud_params=ShearStudParamsDTO(
            base_diameter=20.0,
            top_diameter=30.0,
            base_height=100.0,
            top_height=25.0,
            num_per_section=2,
            transverse_spacing=150.0,
            pitch=300.0
        ),
        girder_segments=[
            GirderSegmentDTO(
                length=25000.0,
                D=900.0,
                tw=10.0,
                T_ft=26.0,
                T_fb=26.0,
                B_ft=500.0,
                B_fb=500.0
            )
        ]
    )

def run_test():
    print("=== Testing IFC Substructure Export Workflow ===")
    
    # 1. Initialize Generator & DTO
    gen = PlateGirderCADGenerator()
    params = get_sample_bridge_params()
    gen._set_parameters(params)

    # 2. Extract components
    extractor = PlateGirderIFCExtractor(gen)
    extracted = extractor.extract()

    print(f"Extracted component categories: {list(extracted.keys())}")
    assert "substructure" in extracted, "Substructure category missing in extraction!"
    
    sub_items = extracted["substructure"]
    print(f"Total substructure items extracted: {len(sub_items)}")
    
    class_counts = {}
    for item in sub_items:
        class_counts[item._class_name] = class_counts.get(item._class_name, 0) + 1
    
    for cls, count in class_counts.items():
        print(f"  - {cls}: {count}")

    assert "SubstructurePierCap" in class_counts, "SubstructurePierCap missing!"
    assert "SubstructurePier" in class_counts, "SubstructurePier missing!"
    assert "SubstructurePileCap" in class_counts, "SubstructurePileCap missing!"
    assert class_counts.get("SubstructurePile", 0) == 4, f"Expected 4 Piles, got {class_counts.get('SubstructurePile')}"
    assert class_counts.get("SubstructureRebar", 0) > 0, "Reinforcing bars missing!"

    # 3. Generate IFC4 file
    out_dir = Path(__file__).resolve().parents[1] / "output"
    out_dir.mkdir(exist_ok=True)
    ifc_path = out_dir / "OsdagBridge_Substructure_Complete.ifc"

    print(f"\nGenerating IFC file at: {ifc_path}")
    generator = BridgeIfcGenerator(str(ifc_path))
    generator.generate_from_extracted_data(extracted, gen)

    assert ifc_path.exists(), "IFC file was not created!"
    file_size_kb = ifc_path.stat().st_size / 1024.0
    print(f"IFC file successfully generated! Size: {file_size_kb:.2f} KB")

    # 4. Parse IFC and verify entities
    f = ifcopenshell.open(str(ifc_path))
    print(f"IFC Schema: {f.schema}")
    assert f.schema == "IFC4", f"Expected schema IFC4, got {f.schema}"

    beams = f.by_type("IfcBeam")
    columns = f.by_type("IfcColumn")
    footings = f.by_type("IfcFooting")
    piles = f.by_type("IfcPile")
    rebars = f.by_type("IfcReinforcingBar")
    plates = f.by_type("IfcPlate")
    slabs = f.by_type("IfcSlab")

    print("\n=== Exported BIM Entity Summary ===")
    print(f"  • IfcBeam (Pier Cap / Girders):     {len(beams)}")
    print(f"  • IfcColumn (Pier Columns):         {len(columns)}")
    print(f"  • IfcFooting (Pile Caps):           {len(footings)}")
    print(f"  • IfcPile (Bored Piles):            {len(piles)}")
    print(f"  • IfcReinforcingBar (Rebar solids): {len(rebars)}")
    print(f"  • IfcPlate (Superstructure Plates): {len(plates)}")
    print(f"  • IfcSlab (Deck Slab):              {len(slabs)}")

    assert len(beams) >= 1, "Pier Cap (IfcBeam) not found!"
    assert len(columns) >= 1, "Pier Column (IfcColumn) not found!"
    assert len(footings) >= 1, "Pile Cap (IfcFooting) not found!"
    assert len(piles) == 4, f"Expected 4 IfcPile entities, found {len(piles)}"
    assert len(rebars) >= 20, f"Expected rebar entities, found {len(rebars)}"

    print("\n[SUCCESS] Substructure and Superstructure fully integrated and verified in IFC4 export!")
    return str(ifc_path)

if __name__ == "__main__":
    run_test()
