"""
Package submission zip for FOSSEE IIT Bombay OsdagBridge assignment.
Excludes .git, .venv, __pycache__, .pytest_cache, .vscode, and temporary logs.
"""
import os
import zipfile

OUTPUT_ZIP = "OsdagBridge_Substructure_Submission.zip"
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

EXCLUDE_DIRS = {
    ".git", ".venv", "venv", "env", "__pycache__", ".pytest_cache",
    ".idea", ".vscode", ".gemini", "node_modules", "dist", "build", "egg-info"
}
EXCLUDE_EXTS = {".pyc", ".pyo", ".pyd", ".log", ".tmp"}

def make_submission_zip():
    print(f"Packaging {ROOT_DIR} into {OUTPUT_ZIP}...")
    zip_path = os.path.join(ROOT_DIR, OUTPUT_ZIP)
    
    # Remove existing zip if present
    if os.path.exists(zip_path):
        os.remove(zip_path)

    file_count = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(ROOT_DIR):
            # Prune excluded directories in-place
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.endswith(".egg-info")]
            
            for file in files:
                if file == OUTPUT_ZIP:
                    continue
                ext = os.path.splitext(file)[1].lower()
                if ext in EXCLUDE_EXTS:
                    continue
                
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, ROOT_DIR)
                
                # Double check no excluded dir is in rel_path
                parts = set(rel_path.replace("\\", "/").split("/"))
                if any(p in EXCLUDE_DIRS for p in parts):
                    continue
                
                zf.write(full_path, arcname=rel_path)
                file_count += 1
                
    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"Successfully packaged {file_count} files into '{OUTPUT_ZIP}' ({size_mb:.2f} MB)")

if __name__ == "__main__":
    make_submission_zip()
